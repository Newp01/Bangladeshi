<?php
$con=mysqli_connect("localhost","root","","web_programming");
if(!$con){
    die("Connection Failed");
}

?>