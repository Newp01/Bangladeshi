# Bank Management System #
This project is develop using php, html, javaScript, Bootstrap and CSS.
## How to run project ##
1. Download zip file
2. Extract zip file and paste soucre code in xammp server htdoc folder
## Please first to provide your email id and password in email.php ##
1. Beacuse this project use PHP Mailer to send email on any task.
2. After this login into your email account that you have provide in file
3. Go to setting and open less secure app access setting otherwise you will face error.
## Features ##
1. Manage balnce record
2. User will deposit Money.
3. Withdraw
4. Transection
5. Transections History
6. After any action like withdraw etc then a proper email will send on account holder email.
## Users ##
1. Super Admin
2. Co-Admin
3. Employee
## Templates ##
## Login ##
![login](https://user-images.githubusercontent.com/77319741/132099318-bacc0e99-a06a-419e-b42a-5dbb9ddc9179.JPG)

## Admin Dashboard ##
![ad](https://user-images.githubusercontent.com/77319741/132099322-37f7c128-83c7-4593-8f66-59bcac41dacb.JPG)

![ad2](https://user-images.githubusercontent.com/77319741/132099331-cf861cf4-be93-4d38-a49b-4a82f1c7ffb0.JPG)

![ad3](https://user-images.githubusercontent.com/77319741/132099335-d428fef6-3489-4ee1-8775-88f97df4d99a.JPG)

![ad_emp](https://user-images.githubusercontent.com/77319741/132099337-daad5e49-b64e-4d3c-9e9c-9e57db7d1625.JPG)

## Employee Dashboard ##
![emp_d](https://user-images.githubusercontent.com/77319741/132099412-9ad9f432-d2ae-440a-9207-32fce6a7314f.JPG)

![emp](https://user-images.githubusercontent.com/77319741/132099339-e2c568f3-beb0-4c92-854b-8f1435f2df9d.JPG)
